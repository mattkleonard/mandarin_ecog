
%% 1) run segment anatomical MR in SPM5
% startup SPM (spm functions are used)
% coregister + reslice CT to anatomical MR
% in SPM5 reference image = MR, source image = CT
% segment MR
%% 2) generate surface for electrodes

% get_mask(subject,gray,white,outputdir,degree of smoothing,threshold) 
% e.g. get_mask(6,0.1) or get_mask(16,0.3)

get_mask_V2('subjectX',... % subject name
    './data/t1_class_2gray.nii',... % gray matter file
    './data/t1_aligned_class.nii',... % white matter file
    './data/t1_aligned.nii',... % t1 file
    './data/',... % where you want to safe the file
    'l',... % 'l' for left 'r' for right
    13,0.2); % settings for smoothing and threshold

%% 3) select electrodes from ct
ctmr
% view result
% save image

%% 4) sort unprojected electrodes
sortElectrodes2;
% saves as electrodes_locx;

%% 5) plot electrodes 2 surface
% electrodes2surf(subject,localnorm index,do not project electrodes closer than 3 mm to surface)

% electrodes2surf(
    % 1: subject
    % 2: number of electrodes local norm for projection (0 = whole grid)
    % 3: 0 = project all electrodes, 1 = only project electrodes > 3 mm
    %    from surface, 2 = only map to closest point (for strips)
    % 4: electrode numbers
    % 5: (optional) electrode matrix.mat (if not given, SPM_select popup)
    % 6: (optional) surface.img (if not given, SPM_select popup)
    % 7: (optional) mr.img for same image space with electrode
    %    positions
% saves automatically a matrix with projected electrode positions and an image
% with projected electrodes
% saves as electrodes_onsurface_filenumber_inputnr2

% 1: for a grid use:
[out_els,out_els_ind]=electrodes2surf(subject,...
    5,1,... % use these settings for the grid
    1:32,... % electrode numbers from the following file
    './data/electrodes_loc1.mat',... % file with electrode XYZ coordinates
    './data/subjectX_surface1_13_02.img',... % surface to which the electrodes are projected
    './data/t1_aligned.nii');

% 2: for a 2xN strip use:
[out_els,out_els_ind]=electrodes2surf(subject,4,1,1:16,'./data/electrodes_loc1.mat','./data/subjectX_surface1_13_02.img','./data/t1_aligned.nii');
% 3: for a 1xN strip use:
[out_els,out_els_ind]=electrodes2surf(subject,0,2,1:8,'./data/electrodes_loc1.mat','./data/subjectX_surface1_13_02.img','./data/t1_aligned.nii');



%% 6) combine electrode files into one and make an image
%
subject='name';
elecmatrix=nan(128,3);
switch subject
    case 'name'
    load('./data/name_electrodesOnsurface1_5.mat'); % F
    elecmatrix(1:48,:)=out_els;
    load('./data/name_electrodesOnsurface1_4.mat'); % P
    elecmatrix(49:64,:)=out_els;
    load('./data/name_electrodesOnsurface2_4.mat'); % P
    elecmatrix(65:80,:)=out_els;
  
    save('./data/name_electrodes_surface_loc_all1.mat','elecmatrix');
    [output,els,els_ind,outputStruct]=position2reslicedImage2(elecmatrix,'./data/ANAT_name031210_6_1-0001.nii');

    for filenummer=1:100
        outputStruct.fname=['./data/electrodes_surface_all' int2str(filenummer) '.img' ];
        if ~exist(outputStruct.fname,'file')>0
            disp(['saving ' outputStruct.fname]);
            % save the data
            spm_write_vol(outputStruct,output);
            break
        end
    end
end

%% 6) generate cortex to render images:
gen_cortex_click('name',0.3,1); 


%% plot on surface

% load cortex
% load electrodes on surface
subject='name';
load(['./data/name_cortex.mat']);
load(['./data/' subject '_electrodes_surface_loc_all1.mat']);

ctmr_gauss_plot(cortex,[0 0 0],0)

el_add(elecmatrix,'b',20);
loc_view(270,0)
label_add(elecmatrix);

print('-painters','-r300','-dpng',strcat(['./figures/name_rot270_0_labels']));



